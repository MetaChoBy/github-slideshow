<?php
include ("connexion.php");

$connexion=connexionBd();
// Création de la requete


?>
<!DOCTYPE html>

<!DOCTYPE html>
<html lang="fr">
<body>
<?php require("./header.php");?>
<main
</main>
<?php require "footer.php";?>
</body>
</html>