
<footer>
    <p>	<a id="goto-admin" href="admin.php">Admin</a></p>
    <p id="extra">
    <p>Images  : licence Adobe </p>
    </p>

</footer>
