---
 mise en page : titre de la diapositive
 : " Bienvenue dans notre deuxième diapositive! "
---

Utilisez la flèche gauche pour revenir en arrière!
